<img src="../images/header.png" width="600">
---

# ACTUALITÉS I CAMBRISTI - Fev. 2026

---

☞[_English_](#_english_)

☞[_Nederlands_](_#nederlands_)

---

###### _French_

## Soirée - Concert 4 mars 2026 - Atelier Hastir - 20h15

Il y a toujours de la place pour deux groupes additionnels.
Les duos sont aussi les bienvenus

Inscription comme groupe [via ce lien](https://www.cambristi.com/register?event=d1ede098-39c2-4046-a865-21de56a89120)

Les réservation pour assister au concert ne sont pas obligatoires.

## Masterclasses Stavelot 2026

Les inscriptions aux masterclasses sont ouvertes à toutes et tous, membres ou pas de CAMBRISTI.

Toutes les informations sont disponibles sur la page  [Stavelot 2026](https://www.cambristi.com/stavelot2026)

## Tutti Baroque 2026

Le stage Tutti Baroque est confirmé aux dates du 14 et 15 novembre 2026

Il aura lieu au Département de Musique Ancienne du Conservatoire Royal de Bruxelles.

Les participants seront accompagnés par des professeurs du Conservatoire Royal de Bruxelles:.

* Benoit Douchy (Violon) - Directeur du Département de Musique Ancienne
* Hervé Douchy (violoncelle)
* Carlota Garcia (Traverso)

et par:

* Marie-Anne Dachy (clavecin)

Ce stage est ouvert à toutes et tous, membres ou pas de CAMBRISTI.

Plus d'information et de détails pratique à venir, mais réservez les dates!. 

## Participant de musiciens non-membres aux soirées-concerts

Nous avons adapté notre politique:

Concernant les événements soirée-concert et Music and Tea, le groupe qui désire jouer doit au moins inclure un membre en
ordre de cotisation.

S'il y a des musiciens non-membres, nous demandons au groupe de s'acquitter d'une contribution de 25 € par musicien
non-membre et par événement, à payer sur le compte de l'association I Cambristi BE05 3101 4179 3575 avant l'événement.

Cette contribution est nécessaire pour couvrir les frais de location des salles et des autres frais que nous avons dans
l'organisation pratique de ces événements..

## Action de votre part, pour les membres de CAMBRISTI:

Plusieurs membres nous ont demandé de pouvoir connaître les préférences de style musical des autres membres, afin de
rechercher plus facilement des partenaires musicaux potentiels.

Pour cela, nous vous demandons de bien vouloir mettre à jour vos informations personnelles sur le site I CAMBRISTI en
cochant les cases de style musical qui sont les vôtres. 

Cela ne vous prendra qu'une minute ou deux et sera précieux pour
toute la communauté.

Pour ce faire, cliquez sur le lien ci-dessous:
[mes informatons personnelles](https://www.cambristi.com/mes-informations-personnelles)

Dans les jours qui suivent, les menus recherches de membres et la liste des membres contiendront cette information

<center><img src="../images/fioriture.png" width="100"></center>

###### _English_

## Evening - Concert 4 March 2026 - Atelier Hastir - 8.15 p.m.

There is always room for two additional groups.
Duos are also welcome.

Register as a group [via this link](https://www.cambristi.com/register?event=d1ede098-39c2-4046-a865-21de56a89120&lang=en)

Reservations to attend the concert are not required.

## Stavelot Masterclasses 2026

Registration for the masterclasses is open to everyone, whether or not they are members of CAMBRISTI.

All information is available on the page [Stavelot 2026](https://www.cambristi.com/stavelot2026?lang=en)

## Tutti Baroque 2026

The Tutti Baroque workshop is confirmed for 14 and 15 November 2026.

It will take place at the Early Music Department of the Royal Conservatory of Brussels (French section).
Participants will be accompanied by teachers from the Royal Conservatory of Brussels:


* Benoit Douchy (violin) – Head of the Early Music Department
* Hervé Douchy (cello)
* Carlota Garcia (traverso)

and by:

* Marie-Anne Dachy (harpsichord)

This course is open to everyone, whether or not they are members of CAMBRISTI.

More information and practical details to come, but save the dates!

## Participation of non-member musicians in concert evenings

We have adapted our policy:

For concert evenings and Music and Tea events, the group wishing to play must include at least one member who is up to date with their membership fees.

If there are non-member musicians, we ask the group to pay a contribution of €25 per non-member musician
per event, payable to the I Cambristi association account BE05 3101 4179 3575 before the event.

This contribution is necessary to cover the cost of hiring venues and other expenses we incur in
the practical organisation of these events.

## Action required on your part, for all CAMBRISTI members:

Several members have asked us to be able to find out the musical style preferences of other members, in order to
make it easier to find potential musical partners.

To do this, we kindly ask you to update your personal information on the I CAMBRISTI website by
ticking the boxes corresponding to your musical style preferences. 

It will only take a minute or two and will be invaluable to
the whole community.

To do this, click on the link below:
[mes informatons personnelles](https://www.cambristi.com/mes-informations-personnelles?lang=en)

In the coming days, member searches and the member list menus will contain this information.

<center><img src="../images/fioriture.png" width="100"></center>


###### _Nederlands_


## Avond - Concert 4 maart 2026 - Atelier Hastir - 20.15 uur

Er is nog plaats voor twee extra groepen.
Duo's zijn ook welkom.

Inschrijving als groep [via deze link](https://www.cambristi.com/register?event=d1ede098-39c2-4046-a865-21de56a89120&lang=nl)

Reserveren voor het concert is niet verplicht.

## Masterclasses Stavelot 2026

De inschrijvingen voor de masterclasses staan open voor iedereen, lid of geen lid van CAMBRISTI.

Alle informatie is beschikbaar op de pagina  [Stavelot 2026](https://www.cambristi.com/stavelot2026&lang=nl)

## Tutti Baroque 2026

De stage Tutti Baroque is bevestigd op 14 en 15 november 2026.

Ze vindt plaats in de afdeling Oude Muziek van het Koninklijk Conservatorium van Brussel (Franstalige sectie).

De deelnemers worden begeleid door docenten van het Koninklijk Conservatorium van Brussel:

* Benoit Douchy (viool) - directeur van de afdeling Oude Muziek
* Hervé Douchy (cello)
* Carlota Garcia (traverso)

en door:

* Marie-Anne Dachy (klavecimbel)

Deze stage staat open voor iedereen, lid of geen lid van CAMBRISTI.

Meer informatie en praktische details volgen nog, maar reserveer alvast de data! 

## Deelname van niet-leden aan concertavonden

We hebben ons beleid aangepast:

Wat betreft de concertavonden en Music and Tea-evenementen moet de groep die wil spelen ten minste één lid hebben dat
zijn contributie heeft betaald.

Als er niet-leden meespelen, vragen we de groep een bijdrage van € 25 per niet-lid
per evenement te betalen op de rekening van de vereniging I Cambristi BE05 3101 4179 3575 vóór het evenement.

Deze bijdrage is nodig om de kosten voor de zaalhuur en andere kosten die we hebben voor
de praktische organisatie van deze evenementen te dekken.

## Wat u moet doen, voor alle leden van CAMBRISTI:

Verschillende leden hebben ons gevraagd om de muzikale voorkeuren van andere leden te kennen, zodat ze
gemakkelijker potentiële muzikale partners kunnen vinden.

Daarom vragen wij u vriendelijk om uw persoonlijke gegevens op de website I CAMBRISTI bij te werken door
de vakjes aan te vinken die overeenkomen met uw muzieksmaak. 

Dit kost u slechts een minuut of twee en is van onschatbare waarde voor
de hele gemeenschap.

Klik hiervoor op de onderstaande link:
[mes informatons personnelles](https://www.cambristi.com/mes-informations-personnelles?lang=nl)

In de komende dagen zullen de zoekfuncties voor leden en de ledenlijst deze informatie bevatten.



---

---

_This mail was send by [I CAMBRISTI ASBL](https://www.cambristi.com/) to its members_

_If you don't want to receive future mails from this address, and cancel your membership, please click on the following
link: [Unsubscribe](https://www.cambristi.com/cancel-membership)_